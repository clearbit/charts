# Running pdf-http

[pdf-http](https://hub.docker.com/r/openlabs/docker-wkhtmltopdf-aas/) Generates a PDF of HTML.

## TL;DR;

```bash
$ helm install pdf-http-x.x.x.tgz --name pdf-http --namespace pdf-http
```
